function onBeatHit()
   if curBeat == 208 then
		characterPlayAnim('dad','goback', true) --this punk sh i will never fix this i already try to fix things but the offset didn't changed at all tf
        setProperty('defaultCamZoom',1.2)
	end
end